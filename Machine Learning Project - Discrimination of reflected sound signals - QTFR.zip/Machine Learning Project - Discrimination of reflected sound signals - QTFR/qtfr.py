import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from joblib import dump, load
from sklearn import metrics

dataframe1 = pd.read_excel("object1.xlsx", header= None)
data1 = np.array(dataframe1)

dataframe2 = pd.read_excel("object2.xlsx", header= None)
data2 = np.array(dataframe2)

n_features = 3

normdata1 = np.zeros((data1.shape[0],data1.shape[1]))
X1 = []
for i in range(data1.shape[0]):
    normdata1[i] = data1[i]/max(abs(data1[i]))
    powerSpectrum, freqenciesFound, time, imageAxis = plt.specgram(normdata1[i], Fs=1)
    plt.close()
    X1.append([np.sum(powerSpectrum),np.argmax(powerSpectrum),np.where(powerSpectrum == np.amax(powerSpectrum))[1][0]])

normdata2 = np.zeros((data2.shape[0],data2.shape[1]))
X2 = []
for i in range(data2.shape[0]):
    normdata2[i] = data2[i]/max(abs(data2[i]))
    powerSpectrum, freqenciesFound, time, imageAxis = plt.specgram(normdata2[i], Fs=1)
    plt.close()
    X2.append([np.sum(powerSpectrum),np.argmax(powerSpectrum),np.where(powerSpectrum == np.amax(powerSpectrum))[1][0]])

X1 = np.array(X1)
X1 = X1.reshape(X1.shape[0],n_features)

X2 = np.array(X2)
X2 = X2.reshape(X2.shape[0],n_features)

X = np.vstack((X1,X2)) # Features
Y = np.hstack((np.zeros(X1.shape[0]),np.ones(X2.shape[0]))) # Labels

x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2, random_state = 42)

nbc = GaussianNB()
nbc.fit(x_train, y_train)
    
dump(nbc,'bayes_classifier_model.joblib')

nbc_loaded = load('bayes_classifier_model.joblib') 
y_pred = nbc_loaded.predict(x_test)

print('Accuracy:',metrics.accuracy_score(y_test, y_pred))
